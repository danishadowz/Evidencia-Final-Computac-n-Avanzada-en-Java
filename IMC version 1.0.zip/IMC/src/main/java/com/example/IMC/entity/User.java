package com.example.IMC.entity;

import static java.lang.Math.pow;
import java.util.Date;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="imc")
@Data
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="id")
    private int id;

    @Column(name="nombre")
    private String nombre;

    @Column(name="apellido")
    private String apellido;

    @Column(name="edad")
    private int edad;

    @Column(name="sexo")
    private char sexo;

    @Column(name="estatura")
    private float estatura;

    @Column(name="peso")
    private float peso;

    @Column (name="imc")
    private float imc;

    @Column(name="fecha")
    @CreationTimestamp
    private Date fecha;

    public User(){ }

    public User(User user) {
        this.nombre = user.getNombre();
        this.apellido = user.getApellido();
        this.edad = user.getEdad();
        this.sexo = user.getSexo();
        this.estatura = user.getEstatura();
        this.peso = user.getPeso();
        this.imc = user.getImc();
        this.fecha = user.getFecha();
    }

    public int getId() {
        return id;}
    public void setId(int id) {
        this.id = id;}
    public String getNombre() {
        return nombre;}
    public void setNombre(String nombre) {
        this.nombre = nombre;}
    public String getApellido() {
        return apellido;}
    public void setApellido(String apellido) {
        this.apellido = apellido;}
    public int getEdad() {
        return edad;}
    public void setEdad(int edad) {
        this.edad = edad;}
    public char getSexo() {
        return sexo;}
    public void setSexo(char sexo) {
        this.sexo = sexo;}
    public float getEstatura() {
        return estatura;}
    public void setEstatura(float estatura) {
        this.estatura = estatura;}
    public float getPeso() {
        return peso;}
    public void setPeso(float peso) {
        this.peso = peso;}
    public float getImc() {
        return imc;}
    public void setImc() {
        this.imc = (float) (peso / pow(estatura,2.0));}
    public Date getFecha() {
        return fecha;}
    public void setFecha(Date fecha) {
        this.fecha = fecha;}



}
