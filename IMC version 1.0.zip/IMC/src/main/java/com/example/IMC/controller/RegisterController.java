package com.example.IMC.controller;

import com.example.IMC.Datos.Info;
import com.example.IMC.entity.User;
import com.example.IMC.service.Servicios;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("imc")
public class RegisterController {

    @Autowired
    Servicios servicios;

    @GetMapping
    public Iterable<User> getUser(){
        return servicios.getUser();
    }

    @GetMapping("{id}")
    public  Optional<User> getUserById(@PathVariable Integer id) {
        return servicios.getUserById(id);
    }

    @PostMapping()
    public ResponseEntity<String> guardarUser(@RequestBody Info info){
        try {
            servicios.guardarUser(new User());
            return new ResponseEntity<>("success", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PutMapping("{id}")
    public ResponseEntity<String> actualizarUser(@PathVariable Integer id, @RequestBody Info info){
        try{
            servicios.actualizarUser(id, new User());
            return new ResponseEntity<>("success", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> borrarUser(@PathVariable Integer id){
        try {
            servicios.borrarUser(id);
            return new ResponseEntity<>("success", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}