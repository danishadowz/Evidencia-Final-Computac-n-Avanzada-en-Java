package com.example.IMC.Datos;

import java.util.Date;
import lombok.Data;

@Data
public class Info {
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private char sexo;
    private float estatura;
    private float peso;
    private float imc;
    private Date fecha;
}
