package com.example.IMC.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Service;
import java.util.Optional;
import com.example.IMC.entity.User;
import com.example.IMC.repository.UserRepository;

@Service
public class Servicios {
    @Autowired
    UserRepository userRepository;

    public Iterable<User> getUser() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(Integer id) {
        return userRepository.findById(id);
    }

    public User guardarUser(User user){
        return userRepository.save(user);
    }

    public User actualizarUser(Integer id, User user){
        user.setId(id);
        return userRepository.save(user);
    }

    public void borrarUser(Integer id){
        Optional<User> user = userRepository.findById(id);
        userRepository.delete(user.get());
    }
}
